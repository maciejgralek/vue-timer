export const mixin = {
	data: function () {
		return {
			message: 'hello',
		}
	}
}
