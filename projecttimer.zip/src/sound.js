export const sound = {
	soundFile: null,

	initSound() {
		this.soundFile = new Audio(require('./assets/ring.wav'));
		this.soundFile.loop = true;
		console.log("sound", this.soundFile);
	},

	play() {
		this.soundFile.play();
	}
}
