
export const store = {
	debug: false,
	state: {
		showSettings: false,
		settingsFontSize: 'medium',
		settings: {
			// fontSize: "medium",
			onZeroAction: "0",
			fontSizes: ["small", "medium", "large"],
			fontSize: 1,
			fontColor: "black",
			backgroundImage: "mountains.jpg"
		},
		timeSet: {
			hours: 0,
			minutes: 30,
			seconds: 0
		},
		timeRestartAfter: {
			hours: 0,
			minutes: 5,
			seconds: 0
		}
	}
};
