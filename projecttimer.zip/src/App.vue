<template>
	<div id="app">
		<navbar></navbar>
		<div class="container-fluid">

			<!-- row -->

			<div class="row">
				<div class="col-12 d-flex">
					<div class="mx-auto">
						<router-view></router-view>
					</div>
				</div>
			</div>

			<!-- row -->

			<div class="row mt-4 justify-content-center">
				<div class="col-6">
					<div class="d-flex align-items-center justify-content-center">
						<transition name="fade">
							<settings v-if="state.showSettings" class="w-100"></settings>
						</transition>
					</div>
				</div>
			</div>

			<!-- row -->

		</div> 
	</div>
</template>

<script>
	let cookie = null;

	import Navbar from './components/Navbar.vue';
	import Settings from './components/Settings.vue';
	import { store } from './store.js'
	// import $ from 'jquery';

	export default {
		components: {
			Navbar,
			Settings
		},
		data() {
			return {
				showSettings: true,
				state: store.state
			}
		},
		methods: {
			test() {
				console.log("TEST");
				store.debug = !(store.debug);
				// axios.post(dburl + '/test', { withCredentials: true })
				// 	.then ((response) => {
				// 		console.log(response);
				// 	})
				// 	.catch ((error) => {
				// 		console.log(error)
				// 	})
				// })
			},
			setupStoreFromCookie() {
				// let settings = this.state.settings;
				// settings.fontSize = cookie.fontSize || "large";
				// console.log(settings.fontSize);
			}
		},
		mounted: function() {
			// document.body.classList.add("bg-image-mountains")
			document.body.style.backgroundImage = "url(" + require("./assets/mountains.jpg") +")"
			document.body.style.backgroundSize = "100% 100%"
			document.body.style.backgroundAttachment = "fixed"
			// this.$cookie.set('settings', store.state.settings)
			let cookieJson = this.$cookie.get('settings');
			if (cookieJson) {
				cookie = JSON.parse(cookieJson);
				this.setupStoreFromCookie();
				console.log("settings", cookie);
			}
		}
	}
</script>

<style>
body {
	overflow-y: scroll
}
.bg-image-mountains {
	background-image: url("./assets/mountains.jpg");
	background-attachment: fixed;
	background-size: 100% 100%
}
.bg-image-landscape {
	/* background-image: url("./assets/landscape.jpg"); */
	background-attachment: fixed;
	background-size: 100% 100%
}
.fade-enter-active, .fade-leave-active {
  transition: opacity .20s;
}
.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}
</style>
