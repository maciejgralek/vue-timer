<!-- <div class="form&#45;group row"> --><!--{{{-->
		<!-- 	<div class="col&#45;4"> -->
		<!-- 		<label for="inputState" class="col&#45;form&#45;label"> -->
		<!-- 			Background image -->
		<!-- 		</label> -->
		<!-- 	</div> -->
		<!-- 	<div class="col&#45;8" @click="setColorBg($event)"> -->
		<!-- 		<button type="button" class="btn btn&#45;secondary" data&#45;toggle="modal" data&#45;target="#exampleModal"> -->
		<!-- 			Select image -->
		<!-- 		</button> -->
		<!-- 	</div> -->
		<!-- </div> -->

		<!-- row font -->

		<!-- <div> -->
		<!-- 	<div class="form&#45;group row"> -->
		<!-- 		<div class="col&#45;3"> -->
		<!-- 			Font -->
		<!-- 		</div> -->
		<!-- 		<div class="col&#45;8"> -->
		<!-- 			<div class="form&#45;check"> -->
		<!-- 				<input class="form&#45;check&#45;input" type="checkbox" value="" id="defaultCheck1"> -->
		<!-- 				<label class="form&#45;check&#45;label" for="defaultCheck1"> -->
		<!-- 					Digital font -->
		<!-- 				</label> -->
		<!-- 			</div> -->
		<!-- 		</div> -->
		<!-- 	</div> -->
		<!--  -->
		<!-- </div> -->
		<!--  -->
		<!-- <!&#45;&#45; modal &#45;&#45;> -->
		<!--  --><!--}}}-->
		<!-- <div class="modal fade" id="exampleModal" tabindex="&#45;1" role="dialog" aria&#45;labelledby="exampleModalLabel" aria&#45;hidden="true"><!&#45;&#45;  &#45;&#45;> --><!--{{{-->
		<!-- 	<div class="modal&#45;dialog modal&#45;dialog&#45;centered" role="document"> -->
		<!-- 		<div class="modal&#45;content"> -->
		<!-- 			<div class="modal&#45;header"> -->
		<!-- 				<button type="button" class="close" data&#45;dismiss="modal" aria&#45;label="Close"> -->
		<!-- 					<span aria&#45;hidden="true">&#38;times;</span> -->
		<!-- 				</button> -->
		<!-- 			</div> -->
		<!-- 			<div class="modal&#45;body" @click="setBackgroundImage($event)"> -->
		<!-- 				<img data&#45;image&#45;name="mountains.jpg" src="../assets/mountains&#45;thumbnail.jpg" class="p&#45;1"> -->
		<!-- 				<img data&#45;image&#45;name="windfarm.jpg" src="../assets/windfarm&#45;thumbnail.jpg" class="p&#45;1"> -->
		<!-- 				<img data&#45;image&#45;name="landscape.jpg" src="../assets/landscape&#45;thumbnail.jpg" class="p&#45;1"> -->
		<!-- 			</div> -->
		<!-- 			<div class="modal&#45;footer"> -->
		<!-- 				<button type="button" class="btn btn&#45;secondary" data&#45;dismiss="modal">Close</button> -->
		<!-- 			</div> -->
		<!-- 		</div> -->
		<!-- 	</div> -->
		<!-- </div><!&#45;&#45;  &#45;&#45;> --><!--}}}-->

