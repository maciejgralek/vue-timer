<template>
	<nav class="navbar navbar-expand-lg navbar-light fixed-top">
		<a class="navbar-brand" href="#">Navbar</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
			<span class="navbar-toggler-icon"></span>
		</button>

		<div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mr-auto">
				<li class="nav-item active">
					<a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#">Link</a>
				</li>
			</ul>
			<a href="" @click.prevent="state.showSettings = !state.showSettings">Settings</a>
		</div>
	</nav>
</template>

<script>
	import { store } from '../store.js'

	export default {
		data: function() {
			return {
				user: {
					email: "fasd@fds.fadsf",
					password: "",
					state: store.state
				}
			};
		},

		computed: {
		},

		methods:{
			submitLogin() {
				this.$emit("login-submit", this.user);
			}
		},

		mounted: function() {
		}
	}
</script>

<style>
.dropdown {
	margin-left: auto;
}
</style>
