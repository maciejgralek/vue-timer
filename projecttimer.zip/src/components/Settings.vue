<template>
	<div id="settings" class="shadow-lg">

		<!-- row -->

		<!-- <div class="row"> -->
		<!-- 	<div class="col&#45;12 pb&#45;4"> -->
		<!-- 		<button type="button" class="close" aria&#45;label="Close"> -->
		<!-- 			<span aria&#45;hidden="true">&#38;times;</span> -->
		<!-- 		</button> -->
		<!-- 	</div> -->
		<!-- </div> -->

		<!-- row time -->

		<div class="form-group row">
			<div class="col-4">
				<label for="inputState" class="col-form-label">
					Timer
				</label>
			</div>
			<div class="col">
				<select 
					 v-model="state.timeSet.hours" 
					 id="inputState" 
					 class="form-control">
					<option value="0" selected>00</option>
					<option value="1" selected>01</option>
				</select>
				<small>Hours</small>
			</div>
			<div class="col">
				<select 
					 v-model="state.timeSet.minutes" 
					 id="inputState" 
					 class="form-control">
					<option value="0">00</option>
					<option v-for="i in 59" :value="i"> {{ i | addZero }} </option>
				</select>
				<small>Minutes</small>
			</div>
			<div class="col">
				<select 
					 v-model="state.timeSet.seconds" 
					 id="inputState" 
					 class="form-control">
					<option value="0" selected>00</option>
					<option v-for="i in 59" :value="i"> {{ i | addZero }} </option>
				</select>
				<small>Seconds</small>
			</div>
		</div>

		<hr>

		<!-- row sound -->

		<div class="form-group row">
			<div class="col-4">
				<label for="inputState" class="col-form-label">
					Sound
				</label>
			</div>
			<div class="col-4">
				<select id="inputState" class="form-control">
					<option selected>Ring</option>
					<option>Ring 2</option>
				</select>
			</div>
			<div class="col">
				<button class="btn btn-secondary btn-sm" @click="playSound">&#9654;</button>
			</div>
			<div class="col">
				<input type="checkbox">Repeat</input>
			</div>

		</div>

		<!-- row on zero -->

		<div class="form-group row">
			<div class="col-4">
				<label for="inputState" class="col-form-label pt-0">
					On zero
				</label>
			</div>
			<div class="col-8">
				<div class="form-group">
					<div class="custom-control custom-radio">
						<input class="custom-control-input" type="radio" id="radio1" value="0" v-model="state.settings.onZeroAction">
						<label class="custom-control-label" for="radio1">
							Do nothing
						</label>
					</div>
					<div class="custom-control custom-radio">
						<input class="custom-control-input" type="radio" id="radio2" value="restart" v-model="state.settings.onZeroAction">
						<label class="custom-control-label" for="radio2">
							Restart
						</label>
					</div>
					<div class="custom-control custom-radio">
						<input class="custom-control-input" type="radio" id="radio3" value="restart2" v-model="state.settings.onZeroAction">
						<label class="custom-control-label" for="radio3">
							Restart after...
						</label>
					</div>
				</div>

				<!-- restart after -->

				<transition name="fade">
				<div class="row" v-if="state.settings.onZeroAction == 'restart2'">
					<div class="col">
						<select 
							 v-model="state.timeRestartAfter.hours" 
							 id="inputState" 
							 class="form-control">
							<option value="0" selected>00</option>
							<option value="1" selected>01</option>
						</select>
						<small>Hours</small>
					</div>
					<div class="col">
						<select 
							 v-model="state.timeRestartAfter.minutes" 
							 id="inputState" 
							 class="form-control">
							<option value="0">00</option>
							<option v-for="i in 59" :value="i"> {{ i | addZero }} </option>
						</select>
						<small>Minutes</small>
					</div>
					<div class="col">
						<select 
							 v-model="state.timeRestartAfter.seconds" 
							 id="inputState" 
							 class="form-control">
							<option value="0" selected>00</option>
							<option v-for="i in 59" :value="i"> {{ i | addZero }} </option>
						</select>
						<small>Seconds</small>
					</div>
				</div>
				</transition>
				<!-- restart after -->

			</div>
		</div>

		<hr>

		<!-- row size -->

		<div class="form-group row">
			<div class="col-4">
				<label for="inputState" class="col-form-label">
					Font size
				</label>
			</div>
			<div class="col-8">
				<button class="btn btn-secondary" @click="setSize(1)"> + </button>
				<button class="btn btn-secondary ml-1" @click="setSize(-1)"> - </button>
			</div>
		</div>

		<!-- row color -->

		<div class="form-group row">
			<div class="col-4">
				<label for="inputState" class="col-form-label">
					Timer color
				</label>
			</div>
			<div class="col-8" @click="setFontColor($event)">
				<span data-color="dark" class="dot bg-dark mx-1"></span>
				<span data-color="dark" class="dot bg-light mx-1"></span>
				<span data-color="dark" class="dot bg-secondary mx-1"></span>
				<span data-color="dark" class="dot bg-info mx-1"></span>
				<span data-color="red" class="dot bg-red mx-1"></span>
			</div>
		</div>

		<!-- row bgcolor-->

		<div class="form-group row">
			<div class="col-4">
				<label for="inputState" class="col-form-label">
					Background color
				</label>
			</div>
			<div class="col-8" @click="setColorBg($event)">
				<span data-bgcolor="dark" class="dot bg-dark mx-1"></span>
				<span data-bgcolor="dark" class="dot bg-light mx-1"></span>
				<span data-bgcolor="dark" class="dot bg-secondary mx-1"></span>
				<span data-bgcolor="dark" class="dot bg-info mx-1"></span>
				<span data-bgcolor="dark" class="dot bg-primary mx-1"></span>
			</div>
		</div>

		<!-- row image -->

		<div class="form-group row">
			<div class="col-4">
				<label for="inputState" class="col-form-label">
					Background image
				</label>
			</div>
			<div class="col-8" @click="setColorBg($event)">
				<button type="button" class="btn btn-secondary" data-toggle="modal" data-target="#exampleModal">
					Select image
				</button>
			</div>
		</div>

		<!-- row font -->

		<div>
			<div class="form-group row">
				<div class="col-4">
					Font
				</div>
				<div class="col-8">
					<div class="form-check">
						<input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
						<label class="form-check-label" for="defaultCheck1">
							Digital font
						</label>
					</div>
				</div>
			</div>

		</div>

		<!-- modal -->

		<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true"><!-- {{{ -->
			<div class="modal-dialog modal-dialog-centered" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body" @click="setBgImage($event)">
						<img data-image-name="mountains.jpg" src="../assets/mountains-thumbnail.jpg" class="p-1">
						<img data-image-name="windfarm.jpg" src="../assets/windfarm-thumbnail.jpg" class="p-1">
						<img data-image-name="landscape.jpg" src="../assets/landscape-thumbnail.jpg" class="p-1">
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div><!-- }}} -->

	</div>
</template>

<script>
	import { store } from '../store.js'
	import { mixin } from '../mixin.js';
	import { sound } from '../sound.js';

	export default {
		mixins: [mixin],

		components: {

		},

		data() {
			return {
				state: store.state,
				showAdvanced: false
			}
		},

		filters: {
			addZero(value) {
				let str = value.toString();
				if (str.length == 1) {
					return "0" + str;
				}

				return str;
			}
		},

		computed: {

		},

		methods: {
			setColorBg(e) {
				console.log(e.target.dataset.bgcolor);
			},

			setFontSize(e) {
				this.state.settingsFontSize = e.target.value;

			},

			setSize(value) {
				this.state.settings.fontSize += value;
			},

			setBgImage(e) {
				let imageName = e.target.dataset.imageName;
				document.body.style.backgroundImage = 
					"url(" + require("../assets/" + imageName) +")"
			},

			setFontColor(e) {
				let color = e.target.dataset.color;
				this.state.settings.fontColor = color;
			},

			playSound() {
				sound.play();
			}
		},

		mounted: function() {

		}
	}
</script>

<style>
@import url('https://fonts.googleapis.com/css?family=Montserrat');
@import url('https://fonts.googleapis.com/css?family=Aldrich');

.dot {
	height: 25px;
	width: 25px;
	background-color: #bbb;
	border-radius: 50%;
	display: inline-block;
	-webkit-box-shadow: 1px 1px 5px 0px rgba(0,0,0,0.3); 
	box-shadow: 1px 1px 5px 0px rgba(0,0,0,0.3);
}
.dot:hover {
	height: 25px;
	width: 25px;
	border-radius: 50%;
	display: inline-block;
	cursor: pointer;
}

#settings {
	background-color: rgba(255,255,255,0.9);
	padding-right: 2em;
	padding-left: 2em;
	padding-bottom: 2em;
	padding-top: 3em;
	border-radius: 5px;
}
.bg-red {
	background-color: red;
}
.fade-enter-active, .fade-leave-active {
  transition: opacity .20s;
}
.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}
</style>
