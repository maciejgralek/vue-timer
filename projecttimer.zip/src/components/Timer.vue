<template>
	<div>
		<div ref="timer" class="timer timer-medium text-center">
			<span v-if="time.hours"> {{ time.hours | addZero }} : </span> 
			{{ time.minutes | addZero }} : {{ time.seconds | addZero }}
		</div>
		<div class="d-flex justify-content-center">
			<button 
				 type="button" 
				 class="btn btn-primary" 
				 @click="startTimer">
				Start
			</button>
			<button 
				 type="button" 
				 class="btn btn-secondary ml-4"
				 @click="resetTimer">
				Reset
			</button>
			<button 
				 type="button" 
				 class="btn btn-secondary ml-4" 
				 @click.prevent="state.showSettings = !state.showSettings">
				Settings
			</button>
		</div>

		<!-- modal -->

		<div class="modal fade" id="alarmModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						Alarm
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import { store } from '../store.js'
	import { mixin } from '../mixin.js'
	import tools from './tools.js';
	import { sound } from '../sound.js'
	import $ from 'jquery';

	export default {
		mixins: [mixin],

		components: {

		},

		data() {
			return {
				time: {
					hours: 0,
					minutes: 0,
					seconds: 0
				},
				delta: 0,
				timeStart: 0,
				interval: null,
				timerAlarm: false,
				state: store.state
			}
		},

		filters: {
			addZero(value) {
				let str = value.toString();
				if (str.length == 1) {
					return "0" + str;
				}

				return str;
			}
		},

		computed: {

		},

		methods: {
			startTimer() {
				this.timeStart = Math.trunc(new Date().getTime() / 1000);
				this.delta = (this.time.hours * 60 * 60) +
					(this.time.minutes * 60) + this.time.seconds;
				this.interval = setInterval(() => {
					let time = Math.trunc(new Date().getTime() / 1000);
					this.time.hours = Math.trunc((this.delta-(time - this.timeStart)) / 60 / 60) % 60;
					this.time.minutes = Math.trunc((this.delta-(time - this.timeStart)) / 60) % 60;
					this.time.seconds = ((this.delta-(time - this.timeStart)) % 60);

					if (!this.time.hours && !this.time.minutes && !this.time.seconds) {
						this.timerAlarm = true;
						sound.play();
						$('#alarmModal').modal('show');
						if (this.state.settings.onZeroAction == 0) {
							this.stopTimer();
						}
						else if (this.state.settings.onZeroAction == "restart") {
							this.resetTimer();
						}
					}
				}, 1000)
			},

			positionComponent() {
				this.$el.style.marginTop = (document.documentElement.clientHeight/2 - 
					this.$el.clientHeight/2)+"px"
			},

			stopTimer() {
				clearInterval(this.interval);
				this.interval = null;
			},

			resetTimer() {
				this.stopTimer();
				tools.copyObjectProperties(this.state.timeSet, this.time);
			},
		},

		watch: {
			'state.timeSet':{
				handler: function () {
					this.time.hours = Number(this.state.timeSet.hours);
					// if (this.state.timeSet.hours == 0) {
					// 	this.time.hours = null;
					// }
					this.time.minutes = Number(this.state.timeSet.minutes);
					this.time.seconds = Number(this.state.timeSet.seconds);

					if (this.interval) {
						this.resetTimer();
					}
				},
				deep: true
			},
			'state.settings.fontSize':{
				handler: function (newValue, oldValue) {
					let index = this.state.settings.fontSize;
					let size = this.state.settings.fontSizes[index];
					this.$el.firstChild.classList.remove("timer-small", "timer-medium", "timer-large")
					this.$el.firstChild.classList.add("timer-" + size)

					this.positionComponent();
				}
			},
			'state.settings.fontColor':{
				handler: function (newValue, oldValue) {
					console.log(newValue, oldValue);
					this.$refs.timer.style.color = newValue;
				}
			}
		},

		mounted: function() {
			tools.copyObjectProperties(this.state.timeSet, this.time)	;
			sound.initSound();
			// sound.soundFile.play();

			console.log("ref", this.$refs);
			this.positionComponent();

			window.addEventListener('resize', this.positionComponent);
		}
	}
</script>

<style>
@import url('https://fonts.googleapis.com/css?family=Montserrat');
@import url('https://fonts.googleapis.com/css?family=Aldrich');
@font-face { font-family: Digital; src: url('../assets/LiquidCrystal-Bold.otf'); } 

.timer-medium {
	font-size: 126px;
	/* font-family: 'Aldrich', sans-serif */
}
.timer-small {
	font-size: 80px;
	/* font-family: 'Aldrich', sans-serif */
}
.timer-large {
	font-size: 210px;
	/* font-family: 'Aldrich', sans-serif */
}
.timer {
	font-family: 'Montserrat', sans-serif;
	/* font-family: 'Aldrich', sans-serif */
	/* font-family: 'Digital' */
}
</style>
