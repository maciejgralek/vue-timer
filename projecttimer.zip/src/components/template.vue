<template>
	<div>

	</div>
</template>

<script>
	import { store } from '../store.js'
	import { mixin } from '../mixin.js';

	export default {
		
		mixins: [mixin],
		components: {

		},
		
		data: function() {
			return {

			}
		},
		filters: {

		},
		computed: {

		},
		methods: {

		},
		mounted: function() {

		}
	}
</script>

<style>

</style>
